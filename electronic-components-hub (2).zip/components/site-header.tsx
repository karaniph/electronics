"use client"

import { useState } from "react"
import Link from "next/link"
import { Search, Menu } from "lucide-react"
import { Logo } from "@/components/logo"
import { MobileMenu } from "@/components/mobile-menu"

export function SiteHeader() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  return (
    <>
      <header className="bg-black text-white">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <Logo variant="white" size="medium" />
              <nav className="hidden md:block ml-10" aria-label="Main Navigation">
                <ul className="flex space-x-8">
                  <li>
                    <Link href="/category/bjt" className="hover:text-gray-300">
                      Transistors
                    </Link>
                  </li>
                  <li>
                    <Link href="/category/mosfet" className="hover:text-gray-300">
                      MOSFETs
                    </Link>
                  </li>
                  <li>
                    <Link href="/category/igbt" className="hover:text-gray-300">
                      IGBTs
                    </Link>
                  </li>
                  <li>
                    <Link href="/category/scr" className="hover:text-gray-300">
                      SCRs
                    </Link>
                  </li>
                  <li>
                    <Link href="/category/ic" className="hover:text-gray-300">
                      ICs
                    </Link>
                  </li>
                </ul>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <Link href="/search" className="hover:text-gray-300" aria-label="Search Components">
                <Search className="h-5 w-5" />
              </Link>
              <Link
                href="/ai-assistant"
                className="hidden md:block bg-white text-black px-4 py-2 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors"
              >
                AI Assistant
              </Link>
              <button className="md:hidden" aria-label="Open Menu" onClick={() => setIsMobileMenuOpen(true)}>
                <Menu className="h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </header>
      <MobileMenu isOpen={isMobileMenuOpen} onClose={() => setIsMobileMenuOpen(false)} />
    </>
  )
}
